var goods = new Array('Aegir', 'Aud', 'Balder');



for(i in goods){
	alert(goods[i]);
}
